CREATE TABLE `__PREFIX__website_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) NOT NULL DEFAULT '' COMMENT '网站域名',
  `name` varchar(200) NOT NULL DEFAULT '' COMMENT '网站名称',
  `cms_api_key` varchar(200) NOT NULL DEFAULT '' COMMENT 'cms-apikey',
  `createtime` int(11) DEFAULT '0',
  `updatetime` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

