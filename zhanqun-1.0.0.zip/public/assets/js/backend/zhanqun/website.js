define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'zhanqun/website/index' + location.search,
                    add_url: 'zhanqun/website/add',
                    edit_url: 'zhanqun/website/edit',
                    del_url: 'zhanqun/website/del',
                    multi_url: 'zhanqun/website/multi',
                    table: 'website_group',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'domain', title: __('Domain')},
                        {field: 'name', title: __('Name')},
                        {field: 'cms_api_key', title: __('Cms_api_key')},
                        {field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', formatter: Table.api.formatter.datetime},
                        {field: 'status', title: __('Status')},
                        {
                            field: 'datalist', title: __('Operate'), table: table,
                            events: {
                                'click .btn-duplicate': function (e, value, row) {

                                    return false;
                                }
                            },
                            buttons: [
                                {
                                    name: 'channel',
                                    text: '子站栏目',
                                    classname: 'btn btn-xs btn-primary btn-addtabs',
                                    icon: 'fa fa-file',
                                    url: 'zhanqun/website/channel?id={id}'
                                },

                                {
                                    name: 'channel',
                                    text: '子站文章列表',
                                    classname: 'btn btn-xs btn-primary btn-addtabs',
                                    icon: 'fa fa-file',
                                    url: 'zhanqun/website/archives?id={id}'
                                },

                            ],
                            formatter: Table.api.formatter.buttons
                        },
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate, formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});