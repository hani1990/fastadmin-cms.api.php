<?php

namespace app\admin\controller\zhanqun;

use app\common\controller\Backend;

/**
 * 
 *
 * @icon fa fa-circle-o
 */
class Website extends Backend
{

    /**
     * Website模型对象
     * @var \app\admin\model\zhanqun\Website
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\zhanqun\Website;

    }

    /**
     * 默认生成的控制器所继承的父类中有index/add/edit/del/multi五个基础方法、destroy/restore/recyclebin三个回收站方法
     * 因此在当前控制器中可不用编写增删改查的代码,除非需要自己控制这部分逻辑
     * 需要将application/admin/library/traits/Backend.php中对应的方法复制到当前控制器,然后进行修改
     */

    /*
     * 获取子站栏目
     * */
    public function channel()
    {
        $id = $this->request->get('id');
        $website = $this->model->where('id', $id)->find();
        $domain = $website['domain'];
        $cms_api_key = $website['cms_api_key'];
        $request_url = $domain.'/addons/cms/api/channel?apikey='.$cms_api_key;
        $ret = file_get_contents($request_url);
        $channel = json_decode($ret, 1)['data'];
        $this->assign('channel', $channel);
        return $this->fetch('channel');
    }

    /*
     * 获取子站文章列表
     * */
    public function archives()
    {
        $id = $this->request->get('id');
        $page = $this->request->get('page', 1);
        $website = $this->model->where('id', $id)->find();
        $domain = $website['domain'];
        $cms_api_key = $website['cms_api_key'];
        $request_url = $domain.'/addons/cms/api/archives?apikey='.$cms_api_key;
        $request_url_channel = $domain.'/addons/cms/api/channel?apikey='.$cms_api_key;
        $ret_channel = file_get_contents($request_url_channel);
        $channel = json_decode($ret_channel, 1)['data'];
        $ret = file_get_contents($request_url);
        $list = json_decode($ret, 1)['data'];

        $url = parse_url($_SERVER["REQUEST_URI"]);

        $query = \app\admin\model\zhanqun\Website::convertUrlQuery($url['query']);
        $uri = $url['path']."?id=".$query['id']."&ids=".$query['ids']."&addtabs=".$query['addtabs'];
        $this->assign('uri', $uri);
        $this->assign('page', $page);
        $this->assign('list', $list);
        $this->assign('channel', $channel);
        $this->assign('id', $id);
        return $this->fetch('archives');
    }

    /**
     * @desc 获取子站文章详情
     * @param $id 子站id
     * @param $ids 文章id
     * */
    public function detail()
    {
        $ids = $this->request->get('ids');
        $id = $this->request->get('id');
        $website = $this->model->where('id', $id)->find();
        $domain = $website['domain'];
        $cms_api_key = $website['cms_api_key'];
        $request_url = $domain.'/addons/cms/api/archive_detail?apikey='.$cms_api_key."&id={$ids}";
        $ret = file_get_contents($request_url);
        $detail = json_decode($ret, 1)['data'];
    }

    /**
     * @desc 删除文章
     * */
    public function delete()
    {
        $ids = $this->request->get('ids');
        $id = $this->request->get('id');
        $website = $this->model->where('id', $id)->find();
        $domain = $website['domain'];
        $cms_api_key = $website['cms_api_key'];
        $request_url = $domain.'/addons/cms/api/del?apikey='.$cms_api_key."&ids={$ids}";
        $ret = file_get_contents($request_url);
        echo $ret;exit();
    }
}
