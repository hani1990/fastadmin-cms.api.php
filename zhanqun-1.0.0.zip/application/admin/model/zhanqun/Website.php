<?php

namespace app\admin\model\zhanqun;

use think\Model;


class Website extends Model
{

    

    

    // 表名
    protected $name = 'website_group';
    
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'int';

    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    /*
     *  $params['channel'] = '深圳大事记';
                    $result = $this->model->allowField(true)->save($params);
                    $ret = \app\admin\model\zhanqun\Website::publishArchives($params);
                    var_dump($ret);
     * */
    public static function publishArchives($data)
    {

        $websites = Website::where('status', 1)->select();
        foreach ($websites as $k => $website){
            $domain = $website['domain'];
            $cms_api_key = $website['cms_api_key'];
            $request_url = $domain.'/addons/cms/api/index?apikey='.$cms_api_key;
            $ret = http($request_url, $data, 'post');
        }
    }




    /**
     * Returns the url query as associative array
     *
     * @param    string    query
     * @return    array    params
     */

    public static function convertUrlQuery($query)

    {

        $queryParts = explode('&', $query);


        $params = array();

        foreach ($queryParts as $param) {

            $item = explode('=', $param);

            $params[$item[0]] = $item[1];

        }


        return $params;

    }


}
