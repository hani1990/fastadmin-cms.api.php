<?php 
 return [
    "table_name" => "fa_website_group",
    "self_path" => "addons/cms/application/controller/Api.php"
];